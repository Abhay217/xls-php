<?php
require('database.php');
$sql="SELECT * FROM `stationery`";
$res=mysqli_query($con,$sql);
$html='<table><tr><td>name</td><td>number</td><td>website</td><td>address</td><td>pincode</td></tr>';
while($row=mysqli_fetch_assoc($res)){
	$html.='<tr><td>'.$row['name'].'</td><td>'.$row['number'].'</td><td>'.$row['website'].'</td><td>'.$row['address'].'</td><td>'.$row['pincode'].'</td></tr>';
}
$html.='</table>';
header('Content-Type:application/xls');
header('Content-Disposition:attachment;filename=report.xls');
echo $html;
?>
